import pandas as pd


class Excel:
    def __init__(self):
        self.file_path = "Timetable.xlsx"  # Replace with your actual file path
        self.sheet_name = "Time Table"  # Adjust if using a different sheet
        self.df = pd.read_excel(self.file_path, sheet_name=self.sheet_name)
        self.process_data()

    def process_data(self):
        # Create a new column for Days
        self.df['Day'] = None

        # Initialize a variable to track the current day
        current_day = None

        # Define the list of days to look for
        days_of_week = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

        # Iterate through the rows to fill the "Day" column
        for index, row in self.df.iterrows():
            # Check if the row contains a day name
            if any(day in str(row[0]) for day in days_of_week):  # Assuming day names are in the first column
                current_day = next((day for day in days_of_week if day in str(row[0])), None)
            
            # Fill the current day into the new column
            self.df.at[index, 'Day'] = current_day

        # Save the updated DataFrame back to Excel
        output_file_path = "updated_timetable.xlsx"
        self.df.to_excel(output_file_path, index=False)
        print(f"Updated file saved to {output_file_path}")

        # Move the "Day" column to the first position
        columns = ['Day'] + [col for col in self.df.columns if col != 'Day']
        self.df = self.df[columns]

        # Inspect the columns of the original DataFrame
        print(self.df.columns)

        # Skip unnecessary rows and reprocess the data to structure it properly
        # Cleaning the data to remove headers, merged cells, and unnecessary rows
        new_df = self.df.iloc[3:]  # Start from the 4th row to skip the title and headers

        # Delete the Unnamed: 0 column
        new_df.drop(columns=["Unnamed: 0"], inplace=True)
        # Delete the Unnamed: 2 column
        new_df.drop(columns=["Unnamed: 2"], inplace=True)

        # Adjust the column names based on the actual number of columns in the DataFrame
        new_df.columns = [
            "Day",
            "Rooms",
            "8:00",
            "9:20",
            "10:45",
            "12:05",
            "01:30",
            "02:50",
            "04:10",
            # "Extra Column"  # Add this if there is an extra column
        ]  # Assign proper column names

        new_df.reset_index(drop=True, inplace=True)

        # Display the first few rows of cleaned data for verification
        print(new_df.head())

        # Impute missing values with 0
        new_df.fillna(0, inplace=True)
        print(new_df.head())

        print(new_df.isnull().sum())

        # Save the cleaned DataFrame to a CSV file
        csv_output_file_path = "cleaned_timetable.xlsx"
        new_df.to_excel(csv_output_file_path, index=False)
        print(f"Cleaned data saved to {csv_output_file_path}")


Excel()