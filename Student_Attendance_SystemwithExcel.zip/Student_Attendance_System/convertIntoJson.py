import pandas as pd
import json

class ScheduleConverter:
    def __init__(self, excel_file):
        self.excel_file = excel_file
        self.schedule = {}

    def read_excel(self):
        self.df = pd.read_excel(self.excel_file)

    def process_schedule(self):
        for index, row in self.df.iterrows():
            day = row['Day']
            room = row['Rooms']
            if room:
                room = room.replace("#", "")
                print("str", room)

            if day not in self.schedule:
                self.schedule[day] = {}
            if room not in self.schedule[day]:
                self.schedule[day][room] = {}

            for time_slot in ['8:00', '9:20', '10:45', '12:05', '01:30', '02:50', '04:10']:
                subject_column = f"{time_slot}"

                if pd.notna(row[subject_column]):
                    subject_info = str(row[subject_column]).split("\n")
                    subject = subject_info[0]
                    teacher = subject_info[2] if len(subject_info) > 1 else ""
                    session = subject_info[1] if len(subject_info) > 1 else ""

                    print(f"Row {index}: Subject Info - {subject_info}")

                    self.schedule[day][room][time_slot] = {
                        "Subject": subject,
                        "Teacher": teacher,
                        "Section": session
                    }
                else:
                    self.schedule[day][room][time_slot] = {
                        "Subject": "0",
                        "Teacher": "1",
                        "Section": "0"
                    }

    def save_to_json(self, output_file):
        with open(output_file, 'w') as json_file:
            json.dump(self.schedule, json_file, indent=4)
        print(f"Conversion Complete! The schedule has been saved to '{output_file}'.")


