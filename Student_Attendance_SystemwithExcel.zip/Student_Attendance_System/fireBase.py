import firebase_admin
from firebase_admin import credentials, db
import numpy as np
import json
import datetime

class Database:
    def __init__(self):
        self.db_reference = 'self.connect_to_database'
        if not firebase_admin._apps:
            cred = credentials.Certificate("atte-5d109-firebase-adminsdk-yrrqb-5cddf8e55e.json")
            firebase_admin.initialize_app(cred, {
                "databaseURL": "https://atte-5d109-default-rtdb.firebaseio.com"
            })


    def get_user(self):
        ref = db.reference('/users')  
        data = ref.get()
        print("Data Fatched: ")
        return data
       
      
    
    def add_user(self,user_data):
        ref = db.reference('')
        new_user_ref = ref.push(user_data)
        print("Data added successfully: ")

    def update_user(self, update_data):
        ref = db.reference()
        ref.update(update_data)
        print("Data is updated")

    def uploadJSonTimeTable(self, FileName):
        with open(FileName) as f:
            data = json.load(f)
        ref = db.reference('/timeTable')
        new_user_ref = ref.push(data)
        print("Data is updated",new_user_ref)

    def get_time_table(self):
        current_day = datetime.datetime.now().strftime("%A")
        ("Today is:", current_day)
        # Reference to '/timeTable' node and get data
        ref = db.reference('/timeTable/-ODO3_Anc_EgJy-gVfqV/'+'Monday')  
        data = ref.get()
        return data


    # Assuming self.timetableList is a dictionary containing the timetable data
# and self.CurrentClassStudentList holds the students for the class.

    def get_class_info(self, section):
        # Reference to the timetable in Firebase Realtime Database
        ref = db.reference('/timeTable/-ODO3_Anc_EgJy-gVfqV/' + 'Monday')
        data = ref.get()  # Get the timetable data from Firebase

        class_info_list = []  # List to hold the results
        
        # Loop through timetable data
        for room, time_slots in data.items():
            for time, details in time_slots.items():
                subject = details.get("Subject", 'N/A')
                teacher = details.get("Teacher", 'N/A')
                current_section = details.get("Section", '').strip()  # Remove extra spaces
                
                # Check if the section matches the given section and if the class matches the room
                if current_section == section:
                    # If section and class match, prepare the data for return
                    class_info = {
                        "Room": room,
                        "Time": time,
                        "Subject": subject,
                        "Teacher": teacher,
                        "Section": current_section,
                    }
                    class_info_list.append(class_info)
                    
        if not class_info_list:
            return {"error": "No matching class found for the given class name and section"}
        
        return class_info_list

# obj = Database()
# obj.get_class_info('BSAI-3A')


  
