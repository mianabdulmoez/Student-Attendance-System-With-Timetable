import pandas as pd
import time

print("1 - Add new User")
print("2 - Mark Attendance")
print("3 - import excel file")

user = int(input("Enter your Choice: "))
if user == 1:
    name = input("Enter User Name: ")
    roll = input("Enter User Roll No: ")
    year = input("Enter User Starting Year: ")
    Major = input("Enter User Deparment: ")
    Section = input("Enter User Section like: BSAI-1A, BSSE-2b, BSSE-3c: ").upper()
    pic = input("Enter the path of the image (e.g., E:\\TanveerAhmad\\Student_Attendance_System\\imagesData\\1.jpeg): ")

    from encodeGenerator import AddUser
    db_instance = AddUser(name, roll, year,Section,Major)
    db_instance.AddUserData(pic) 
    
    from fireBase import Database
    db = Database()
    db.get_user()

elif user == 2:
    from Opencamera import Camera
    Camera.run() 
elif user == 3:
    from readExcelFile  import Excel
    excl = Excel()
    from convertIntoJson import ScheduleConverter
    converter = ScheduleConverter('cleaned_timetable.xlsx')
    converter.read_excel()
    converter.process_schedule()
    converter.save_to_json('converted_schedule.json')
    from fireBase import Database
    db = Database()
    db.uploadJSonTimeTable("converted_schedule.json") 
    
    

    